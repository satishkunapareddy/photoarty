# PhotoArt
This app is built to showcase few best pictures that I have clicked!
## Features of the App
User can filter the pictures using the categories provided.
User can share image link on any other compatible app installed on their device.
